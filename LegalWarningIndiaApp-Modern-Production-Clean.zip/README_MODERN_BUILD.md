# Legal Warning India — Modern Build

This build redesigns the app around a modern Material 3 legal-tech UI and adds service-specific payment flow.

## Service fees
- Online Consultation — ₹799
- Document Drafting — ₹1,499
- Document Review — ₹999
- Legal Notice Drafting — ₹2,499
- FIR / Complaint Drafting — ₹1,499
- Property Documentation — ₹1,999
- Employment Matters — ₹799
- Business Agreements — ₹2,499
- Cyber Fraud Assistance — ₹999
- General Legal Guidance — ₹799

## Payment architecture
Non-consultation services call:
- POST /wp-json/lwi-app/v1/service/payment/order
- POST /wp-json/lwi-app/v1/service/payment/verify

The server must determine the amount and verify Razorpay signatures. The Android app never contains the Razorpay secret.

## Build
This environment does not include Android SDK/Gradle. Build in GitHub Codespaces:

```bash
gradle :app:compileDebugKotlin
gradle :app:assembleDebug
```

APK:
`app/build/outputs/apk/debug/app-debug.apk`
