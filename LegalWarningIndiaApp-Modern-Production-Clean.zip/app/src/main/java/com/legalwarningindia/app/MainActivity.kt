package com.legalwarningindia.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import com.razorpay.Checkout
import com.razorpay.PaymentData
import com.razorpay.PaymentResultWithDataListener
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val SITE = "https://legalwarningindia.in"
private const val POSTS = "$SITE/wp-json/wp/v2/posts?per_page=20&_fields=id,link,title,excerpt,content,date"
private const val COURSES = "$SITE/wp-json/wp/v2/courses?per_page=50&_fields=id,slug,title,link,date"
private const val STUDY_SEARCH = "$SITE/wp-json/wp/v2/search?search=study&per_page=20&subtype=post"
private const val RAZORPAY_FALLBACK_KEY = "rzp_test_TaF83g0aFI6IpB"
private const val TAG = "LWI_App"

private val Navy = Color(0xFF08233F)
private val Navy2 = Color(0xFF123F68)
private val Gold = Color(0xFFF2B84B)
private val Ink = Color(0xFF14202E)
private val Muted = Color(0xFF687789)
private val Page = Color(0xFFF6F8FB)
private val Success = Color(0xFF16865B)

data class Article(val id:Int,val title:String,val excerpt:String,val content:String,val date:String,val link:String)
data class Course(val id:Int,val title:String,val link:String)
data class StudyItem(val id:Int,val title:String,val link:String)
data class Service(val key:String,val title:String,val fee:Int,val icon:String,val description:String)
data class AppRequest(val id:Int,val token:String,val status:String,val message:String,val paymentRequired:Boolean=true)
data class PaymentOrder(val requestId:Int,val orderId:String,val amount:Int,val currency:String,val keyId:String,val service:String)
data class RequestStatus(val id:Int,val service:String,val status:String,val statusLabel:String,val submittedAt:String,val updatedAt:String)

private val SERVICES = listOf(
    Service("consultation","Online Consultation",799,"chat","Discuss your legal query and receive general procedural information."),
    Service("drafting","Document Drafting",1499,"document","Professional drafting support for specified legal documents."),
    Service("review","Document Review",999,"review","Review of documents with practical observations and guidance."),
    Service("legal-notice","Legal Notice Drafting",2499,"notice","Drafting support for a legal notice based on the facts supplied."),
    Service("fir-complaint","FIR / Complaint Drafting",1499,"fir","Assistance with structuring a factual complaint or representation."),
    Service("property","Property Documentation",1999,"property","Practical documentation support for property-related matters."),
    Service("employment","Employment Matters",799,"employment","General procedural information for salary and employment issues."),
    Service("business","Business Agreements",2499,"business","Drafting support for specified business and commercial agreements."),
    Service("cyber","Cyber Fraud Assistance",999,"cyber","General guidance for cyber-fraud reporting and evidence preservation."),
    Service("general","General Legal Guidance",799,"general","General legal awareness and procedural information."),
)

class MainActivity: ComponentActivity(), PaymentResultWithDataListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Checkout.preload(applicationContext)
        setContent { LegalWarningIndiaApp() }
    }

    override fun onPaymentSuccess(razorpayPaymentID: String, paymentData: PaymentData) {
        val orderId = paymentData.orderId ?: ""
        val signature = paymentData.signature ?: ""
        val requestId = pendingRequestId
        val token = pendingRequestToken
        lifecycleScope.launch {
            val verified = verifyServicePayment(requestId, token, razorpayPaymentID, orderId, signature)
            paymentResult = if (verified) "success" else "pending"
            paymentMessage = if (verified) "Payment verified securely. Your service request is now marked paid." else "Payment callback received, but server verification did not complete. Check Request Status before retrying."
            setContent { LegalWarningIndiaApp() }
        }
    }

    override fun onPaymentError(code: Int, response: String) {
        Log.e(TAG, "Razorpay error $code: $response")
        paymentResult = "failed"
        paymentMessage = "Payment was not completed. No request was marked paid. You can retry."
        setContent { LegalWarningIndiaApp() }
    }

    companion object {
        var pendingRequestId = 0
        var pendingRequestToken = ""
        var pendingService = ""
        var paymentResult = ""
        var paymentMessage = ""
    }
}

@Composable
fun LegalWarningIndiaApp() {
    val nav = rememberNavController()
    MaterialTheme(colorScheme = lightColorScheme(
        primary = Navy2,
        secondary = Gold,
        background = Page,
        surface = Color.White,
        onBackground = Ink,
        onSurface = Ink
    )) {
        Scaffold(bottomBar = { ModernBottomBar(nav) }) { padding ->
            NavHost(navController = nav, startDestination = "home", modifier = Modifier.padding(padding)) {
                composable("home") { Home(nav) }
                composable("news") { News(nav) }
                composable("services") { Services(nav) }
                composable("service/{key}") { b ->
                    val key = b.arguments?.getString("key") ?: "general"
                    val service = SERVICES.firstOrNull { it.key == key } ?: SERVICES.last()
                    ServiceDetails(nav, service)
                }
                composable("payment/{key}/{requestId}/{token}") { b ->
                    val key = b.arguments?.getString("key") ?: "general"
                    val requestId = b.arguments?.getString("requestId")?.toIntOrNull() ?: 0
                    val token = b.arguments?.getString("token") ?: ""
                    val service = SERVICES.firstOrNull { it.key == key } ?: SERVICES.last()
                    PaymentSummary(nav, service, requestId, token)
                }
                composable("consult") { Consultation(nav) }
                composable("requests") { MyRequests() }
                composable("study") { StudyAndCourses() }
                composable("profile") { Profile() }
                composable("article/{id}") { b -> ArticlePage(b.arguments?.getString("id")?.toIntOrNull() ?: 0) }
                composable("payment-result") { PaymentResultScreen() }
            }
        }
    }
}

@Composable
fun ModernBottomBar(nav: NavHostController) {
    val current = nav.currentBackStackEntryAsState().value?.destination?.route
    NavigationBar(containerColor = Color.White, tonalElevation = 8.dp) {
        val tabs = listOf(
            Triple("home","Home",Icons.Default.Home),
            Triple("news","News",Icons.Default.Article),
            Triple("services","Services",Icons.Default.Gavel),
            Triple("study","Study",Icons.Default.School),
            Triple("profile","Profile",Icons.Default.Person)
        )
        tabs.forEach { (route,label,icon) ->
            NavigationBarItem(
                selected = current == route,
                onClick = { nav.navigate(route) { launchSingleTop = true } },
                icon = { Icon(icon, label) },
                label = { Text(label, fontSize = 11.sp) }
            )
        }
    }
}

@Composable
fun Home(nav: NavHostController) {
    LazyColumn(
        Modifier.fillMaxSize().background(Page).padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)).background(Navy), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Balance, null, tint = Gold, modifier = Modifier.size(27.dp))
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("The Legal Warning India", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = Navy)
                    Text("Legal awareness • Practical procedures", color = Muted, fontSize = 11.sp)
                }
                Icon(Icons.Default.NotificationsNone, null, tint = Navy2)
            }
        }
        item {
            Card(
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = Navy),
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(Modifier.fillMaxWidth().height(210.dp)) {
                    Column(Modifier.padding(22.dp).fillMaxWidth(0.78f)) {
                        Text("Know the Law.", color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.ExtraBold)
                        Text("Protect Your Rights.", color = Gold, fontSize = 29.sp, fontWeight = FontWeight.ExtraBold)
                        Text("Legal news, practical information and online legal services.", color = Color(0xFFD7E4F1), modifier = Modifier.padding(top = 10.dp), lineHeight = 19.sp)
                        Button(onClick = { nav.navigate("services") }, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Navy), modifier = Modifier.padding(top = 14.dp)) {
                            Text("Explore Services", fontWeight = FontWeight.Bold)
                            Spacer(Modifier.width(7.dp)); Icon(Icons.Default.ArrowForward, null, Modifier.size(18.dp))
                        }
                    }
                    Icon(Icons.Default.Balance, null, tint = Color(0x35FFFFFF), modifier = Modifier.size(150.dp).align(Alignment.BottomEnd).padding(18.dp))
                }
            }
        }
        item { SectionTitle("Choose your legal problem", "Find a relevant service quickly") }
        item {
            val quick = listOf(
                "Cyber" to Icons.Default.Security,
                "Criminal" to Icons.Default.Gavel,
                "Property" to Icons.Default.Home,
                "Employment" to Icons.Default.Work,
                "Documents" to Icons.Default.Description,
                "Business" to Icons.Default.Business
            )
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                quick.chunked(3).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        row.forEach { (label,icon) ->
                            SmallFeature(label, icon, Modifier.weight(1f)) { nav.navigate("services") }
                        }
                        repeat(3-row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
        }
        item { SectionTitle("Popular services", "Clear fees • Secure request • Online payment") }
        items(SERVICES.take(4)) { service -> ServiceCompactCard(service) { nav.navigate(if (service.key == "consultation") "consult" else "service/${service.key}") } }
        item {
            Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFEAF3FF)), modifier = Modifier.fillMaxWidth().clickable { nav.navigate("news") }) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(44.dp).clip(CircleShape).background(Color.White), contentAlignment = Alignment.Center) { Icon(Icons.Default.Newspaper, null, tint = Navy2) }
                    Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text("Latest Legal Updates", fontWeight = FontWeight.Bold); Text("Read current articles from the website", color = Muted, fontSize = 12.sp) }
                    Icon(Icons.Default.ChevronRight, null)
                }
            }
        }
        item { Spacer(Modifier.height(8.dp)) }
    }
}

@Composable
fun SectionTitle(title:String, subtitle:String) {
    Column {
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
        Text(subtitle, fontSize = 12.sp, color = Muted, modifier = Modifier.padding(top = 2.dp))
    }
}

@Composable
fun SmallFeature(label:String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier:Modifier, onClick:()->Unit) {
    Card(modifier.fillMaxWidth().height(94.dp).clickable { onClick() }, shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(1.dp)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = Navy2, modifier = Modifier.size(25.dp))
            Text(label, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        }
    }
}

@Composable
fun ServiceCompactCard(service:Service,onClick:()->Unit) {
    Card(Modifier.fillMaxWidth().clickable { onClick() }, shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(1.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(48.dp).clip(RoundedCornerShape(15.dp)).background(Color(0xFFEAF2FC)), contentAlignment = Alignment.Center) {
                Icon(serviceIcon(service.key), null, tint = Navy2)
            }
            Spacer(Modifier.width(13.dp)); Column(Modifier.weight(1f)) {
                Text(service.title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(service.description, color = Muted, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 3.dp))
                Text("₹${service.fee}", color = Navy2, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, modifier = Modifier.padding(top = 6.dp))
            }
            Icon(Icons.Default.ChevronRight, null, tint = Muted)
        }
    }
}

@Composable
fun Services(nav:NavHostController) {
    LazyColumn(Modifier.fillMaxSize().background(Page).padding(16.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
        item {
            Spacer(Modifier.height(8.dp)); Text("Our Services", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = Navy)
            Text("Choose a service. Each service has its own fee and payment flow.", color = Muted, modifier = Modifier.padding(top = 4.dp, bottom = 8.dp))
        }
        items(SERVICES) { service ->
            ServiceCompactCard(service) { nav.navigate(if (service.key == "consultation") "consult" else "service/${service.key}") }
        }
        item { Text("Fees are shown in INR. Final scope is based on the information and documents supplied.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(vertical = 8.dp)) }
    }
}

@Composable
fun ServiceDetails(nav:NavHostController, service:Service) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<AppRequest?>(null) }

    if (result != null) {
        PaymentGate(nav, service, result!!)
        return
    }

    LazyColumn(Modifier.fillMaxSize().background(Page).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) { IconButton({ nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, null) }; Text(service.title, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, color = Navy) }
            Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Text("Service fee", color = Muted, fontSize = 12.sp); Text("₹${service.fee}", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = Navy)
                    Text(service.description, color = Muted, modifier = Modifier.padding(top = 5.dp))
                }
            }
            Text("Request details", fontSize = 19.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
        }
        item { Field("Your Name *", name, {name=it}) }
        item { Field("Mobile Number *", phone, {phone=it}) }
        item { Field("Email (Optional)", email, {email=it}) }
        item { Field("Describe your legal matter *", message, {message=it}, minLines = 5) }
        item {
            if(error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
            Button(onClick = { loading = true; error = "" }, enabled = !loading && name.isNotBlank() && phone.isNotBlank() && message.isNotBlank(), modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(17.dp)) {
                if(loading) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = Color.White) else { Text("Create Service Request", fontWeight = FontWeight.Bold); Spacer(Modifier.width(8.dp)); Icon(Icons.Default.ArrowForward, null) }
            }
            Text("Do not share passwords, OTPs, PINs or unnecessary sensitive data.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
            LaunchedEffect(loading) {
                if(loading) {
                    val r = submitRequest(service.key, name, phone, email, message)
                    if(r != null) result = r else error = "Request could not be submitted. Please try again."
                    loading = false
                }
            }
        }
    }
}

@Composable
fun PaymentGate(nav:NavHostController, service:Service, result:AppRequest) {
    Column(Modifier.fillMaxSize().background(Page).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Spacer(Modifier.height(20.dp)); Box(Modifier.size(66.dp).clip(CircleShape).background(Color(0xFFE8F7F0)), contentAlignment = Alignment.Center) { Icon(Icons.Default.CheckCircle, null, tint = Success, modifier = Modifier.size(38.dp)) }
        Text("Request created", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, color = Navy)
        Text("Your request #${result.id} is ready for secure payment.", color = Muted)
        Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(service.title, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                HorizontalDivider()
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Total amount"); Text("₹${service.fee}", fontWeight = FontWeight.ExtraBold, color = Navy2, fontSize = 20.sp) }
            }
        }
        Button({ nav.navigate("payment/${service.key}/${result.id}/${Uri.encode(result.token)}") }, Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(17.dp)) { Text("Proceed to Secure Payment", fontWeight = FontWeight.Bold); Spacer(Modifier.width(8.dp)); Icon(Icons.Default.Lock, null) }
        OutlinedButton({ nav.navigate("requests") }, Modifier.fillMaxWidth()) { Text("Check Request Status") }
    }
}

@Composable
fun PaymentSummary(nav:NavHostController, service:Service, requestId:Int, token:String) {
    val context = LocalContext.current
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().background(Page).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Spacer(Modifier.height(20.dp)); Text("Payment Summary", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = Navy)
        Text("Review your service and continue to Razorpay.", color = Muted)
        Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(service.title, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text("Service fee", color = Muted, fontSize = 12.sp)
                Text("₹${service.fee}", fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, color = Navy)
                Text("Secure payment through Razorpay. Payment is verified server-side.", color = Muted, fontSize = 12.sp)
            }
        }
        if(error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
        Button(onClick = {
            loading = true; error = ""
            (context as? MainActivity)?.lifecycleScope?.launch {
                val order = fetchServicePaymentOrder(requestId, token, service.key)
                if(order == null) { error = "Unable to create payment order. Please try again."; loading = false }
                else {
                    MainActivity.pendingRequestId = requestId; MainActivity.pendingRequestToken = token; MainActivity.pendingService = service.key
                    try {
                        val checkout = Checkout()
                        checkout.setKeyID(order.keyId.ifBlank { RAZORPAY_FALLBACK_KEY })
                        val options = JSONObject().apply {
                            put("name", "Legal Warning India")
                            put("description", service.title)
                            put("order_id", order.orderId)
                            put("amount", order.amount)
                            put("currency", order.currency)
                            put("theme.color", "#123F68")
                            put("retry", JSONObject().apply { put("enabled", true); put("max_count", 4) })
                        }
                        checkout.open(context as MainActivity, options)
                    } catch (e:Exception) { Log.e(TAG, "Checkout open failed", e); error = "Razorpay Checkout could not be opened. Please try again." }
                    loading = false
                }
            }
        }, enabled = !loading, modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(18.dp), colors = ButtonDefaults.buttonColors(containerColor = Navy)) {
            if(loading) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = Color.White) else { Icon(Icons.Default.Lock, null); Spacer(Modifier.width(8.dp)); Text("Pay ₹${service.fee} Securely", fontWeight = FontWeight.Bold) }
        }
        Text("Never share OTPs, card PINs or passwords with anyone.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun PaymentResultScreen() {
    val result = MainActivity.paymentResult
    val message = MainActivity.paymentMessage
    val success = result == "success"
    Column(Modifier.fillMaxSize().background(if(success) Color(0xFFF0FBF6) else Page).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Box(Modifier.size(86.dp).clip(CircleShape).background(if(success) Color(0xFFD9F5E8) else Color(0xFFFFE8E8)), contentAlignment = Alignment.Center) { Icon(if(success) Icons.Default.Check else Icons.Default.Info, null, tint = if(success) Success else Color(0xFFB23A3A), modifier = Modifier.size(45.dp)) }
        Spacer(Modifier.height(18.dp)); Text(if(success) "Payment Successful" else "Payment Status", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, color = Navy)
        Text(message, color = Muted, modifier = Modifier.padding(top = 8.dp))
    }
}

@Composable
fun Consultation(nav:NavHostController) {
    var name by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }; var email by remember { mutableStateOf("") }; var message by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }; var error by remember { mutableStateOf("") }; var result by remember { mutableStateOf<AppRequest?>(null) }
    if(result != null) { PaymentGate(nav, SERVICES.first(), result!!); return }
    LazyColumn(Modifier.fillMaxSize().background(Page).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Row(verticalAlignment = Alignment.CenterVertically) { IconButton({nav.popBackStack()}) {Icon(Icons.Default.ArrowBack,null)}; Text("Online Consultation",fontSize=25.sp,fontWeight=FontWeight.ExtraBold,color=Navy) } }
        item { Card(shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(containerColor=Navy),modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(20.dp)){Text("₹799",fontSize=31.sp,fontWeight=FontWeight.ExtraBold,color=Gold);Text("General consultation booking",color=Color.White,modifier=Modifier.padding(top=3.dp));Text("Payment is verified securely before the request is marked paid.",color=Color(0xFFD7E4F1),fontSize=12.sp,modifier=Modifier.padding(top=7.dp))}} }
        item { Field("Your Name *",name,{name=it}); Field("Mobile Number *",phone,{phone=it}); Field("Email (Optional)",email,{email=it}); Field("Describe your legal query *",message,{message=it},5) }
        item { if(error.isNotBlank()) Text(error,color=MaterialTheme.colorScheme.error); Button({loading=true;error=""},enabled=!loading&&name.isNotBlank()&&phone.isNotBlank()&&message.isNotBlank(),modifier=Modifier.fillMaxWidth().height(54.dp),shape=RoundedCornerShape(17.dp)){if(loading)CircularProgressIndicator(Modifier.size(20.dp),strokeWidth=2.dp,color=Color.White)else Text("Book Consultation • ₹799",fontWeight=FontWeight.Bold)}; LaunchedEffect(loading){if(loading){val r=submitConsultationBooking(name,phone,email,message);if(r!=null)result=r else error="Consultation request could not be submitted. Please try again.";loading=false}} }
    }
}

@Composable
fun Field(label:String,value:String,onChange:(String)->Unit,minLines:Int=1){ OutlinedTextField(value,onChange,label={Text(label)},modifier=Modifier.fillMaxWidth(),minLines=minLines,shape=RoundedCornerShape(16.dp)) }

@Composable
fun News(nav:NavHostController){
    var list by remember{mutableStateOf<List<Article>>(emptyList())}; var loading by remember{mutableStateOf(true)}
    LaunchedEffect(Unit){list=fetchArticles();loading=false}
    LazyColumn(Modifier.fillMaxSize().background(Page).padding(16.dp),verticalArrangement=Arrangement.spacedBy(11.dp)){
        item{Spacer(Modifier.height(8.dp));Text("Legal News",fontSize=28.sp,fontWeight=FontWeight.ExtraBold,color=Navy);Text("Current legal awareness and updates from the website.",color=Muted,modifier=Modifier.padding(top=3.dp,bottom=8.dp))}
        if(loading)item{Box(Modifier.fillMaxWidth().height(180.dp),contentAlignment=Alignment.Center){CircularProgressIndicator()}}
        else if(list.isEmpty())item{EmptyState("No articles could be loaded","Please check your internet connection and try again.")}
        else items(list){a->Card(Modifier.fillMaxWidth().clickable{nav.navigate("article/${a.id}")},shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){Column(Modifier.padding(16.dp)){Text(a.title,fontWeight=FontWeight.Bold,fontSize=16.sp);Text(strip(a.excerpt),color=Muted,maxLines=3,overflow=TextOverflow.Ellipsis,modifier=Modifier.padding(top=6.dp));Text("Read article →",color=Navy2,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=9.dp))}}}
    }
}

@Composable
fun StudyAndCourses(){
    val context=LocalContext.current;var courses by remember{mutableStateOf<List<Course>>(emptyList())};var study by remember{mutableStateOf<List<StudyItem>>(emptyList())};var loading by remember{mutableStateOf(true)}
    LaunchedEffect(Unit){val pair=fetchStudyAndCourses();courses=pair.first;study=pair.second;loading=false}
    LazyColumn(Modifier.fillMaxSize().background(Page).padding(16.dp),verticalArrangement=Arrangement.spacedBy(11.dp)){
        item{Spacer(Modifier.height(8.dp));Text("Study & Courses",fontSize=28.sp,fontWeight=FontWeight.ExtraBold,color=Navy);Text("Only published learning content available on the website is shown here.",color=Muted,modifier=Modifier.padding(top=3.dp,bottom=8.dp))}
        if(loading)item{Box(Modifier.fillMaxWidth().height(150.dp),contentAlignment=Alignment.Center){CircularProgressIndicator()}}
        item{Text("Courses",fontSize=19.sp,fontWeight=FontWeight.Bold)}
        if(!loading&&courses.isEmpty())item{EmptyState("No courses are currently available","New published courses will appear here automatically.")}
        items(courses){c->Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFFFFF2D4)),contentAlignment=Alignment.Center){Icon(Icons.Default.School,null,tint=Navy2)};Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(c.title,fontWeight=FontWeight.Bold);Text("Published course",color=Muted,fontSize=11.sp)}};IconButton({context.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(c.link)))}){Icon(Icons.Default.ArrowOutward,null)}}}}
        if(study.isNotEmpty()){item{Text("Study material",fontSize=19.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=8.dp))};items(study){s->Card(Modifier.fillMaxWidth().clickable{context.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(s.link)))},shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){Row(Modifier.padding(15.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.MenuBook,null,tint=Navy2);Spacer(Modifier.width(12.dp));Text(s.title,fontWeight=FontWeight.SemiBold,modifier=Modifier.weight(1f));Icon(Icons.Default.ChevronRight,null)}}}}
    }
}

@Composable
fun MyRequests(){
    val context=LocalContext.current;var id by remember{mutableStateOf("")};var token by remember{mutableStateOf("")};var loading by remember{mutableStateOf(false)};var status by remember{mutableStateOf<RequestStatus?>(null)};var error by remember{mutableStateOf("")}
    LazyColumn(Modifier.fillMaxSize().background(Page).padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{Spacer(Modifier.height(8.dp));Text("My Requests",fontSize=28.sp,fontWeight=FontWeight.ExtraBold,color=Navy);Text("Check the latest status using your request ID and private token.",color=Muted)};item{Field("Request ID",id,{id=it.filter{c->c.isDigit()}});Field("Private Token",token,{token=it});if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error);Button({loading=true;error=""},enabled=!loading,modifier=Modifier.fillMaxWidth().height(52.dp),shape=RoundedCornerShape(16.dp)){if(loading)CircularProgressIndicator(Modifier.size(20.dp),strokeWidth=2.dp,color=Color.White)else Text("Check Status",fontWeight=FontWeight.Bold)};LaunchedEffect(loading){if(loading){status=fetchRequestStatus(id.toIntOrNull()?:0,token);if(status==null)error="Request not found or token is invalid.";loading=false}}};status?.let{s->item{Card(shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(containerColor=Color.White),modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(18.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){Text("Request #${s.id}",fontSize=19.sp,fontWeight=FontWeight.Bold);Text(s.service);Text(s.statusLabel,fontWeight=FontWeight.Bold,color=Navy2);Text("Submitted: ${s.submittedAt}",color=Muted,fontSize=12.sp);if(s.updatedAt.isNotBlank())Text("Updated: ${s.updatedAt}",color=Muted,fontSize=12.sp)}}}}}
}

@Composable
fun Profile(){LazyColumn(Modifier.fillMaxSize().background(Page).padding(18.dp),verticalArrangement=Arrangement.spacedBy(13.dp)){item{Spacer(Modifier.height(8.dp));Card(shape=RoundedCornerShape(26.dp),colors=CardDefaults.cardColors(containerColor=Navy),modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(22.dp)){Box(Modifier.size(66.dp).clip(CircleShape).background(Color.White.copy(alpha=.12f)),contentAlignment=Alignment.Center){Icon(Icons.Default.Person,null,tint=Gold,modifier=Modifier.size(38.dp))};Text("Uday Singh, Advocate",color=Color.White,fontSize=23.sp,fontWeight=FontWeight.ExtraBold,modifier=Modifier.padding(top=14.dp));Text("LL.B., M.Sc., BCA",color=Gold,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=3.dp));Text("Cyber Matters • Criminal Matters • Digital Evidence • Practical Legal Procedures",color=Color(0xFFD7E4F1),modifier=Modifier.padding(top=10.dp))}};item{Card(shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=Color.White),modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(18.dp)){Text("About Legal Warning India",fontWeight=FontWeight.Bold,fontSize=18.sp);Text("Legal awareness, current legal developments and practical procedural information.",color=Muted,modifier=Modifier.padding(top=6.dp))}}};item{Text("Disclaimer",fontWeight=FontWeight.Bold);Text("This app is for general legal information and awareness purposes only. It does not constitute legal advice or solicitation. Communication is purely informational, in compliance with Bar Council of India Rule 36.",color=Muted,fontSize=12.sp)}}}

@Composable
fun ArticlePage(id:Int){val context=LocalContext.current;var article by remember{mutableStateOf<Article?>(null)};LaunchedEffect(id){article=fetchArticles().firstOrNull{it.id==id}};if(article==null)Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){CircularProgressIndicator()}else LazyColumn(Modifier.fillMaxSize().background(Page).padding(18.dp)){item{Text(article!!.title,fontSize=28.sp,fontWeight=FontWeight.ExtraBold,color=Navy);Text("The Legal Warning India",color=Muted,fontSize=12.sp,modifier=Modifier.padding(top=7.dp));Text(strip(article!!.content),fontSize=16.sp,lineHeight=24.sp,modifier=Modifier.padding(top=18.dp));Button({context.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(article!!.link)))},modifier=Modifier.fillMaxWidth().padding(top=18.dp)){Text("Open Full Article")}}}}

@Composable fun EmptyState(title:String,message:String){Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){Column(Modifier.padding(22.dp),horizontalAlignment=Alignment.CenterHorizontally){Icon(Icons.Default.CloudOff,null,tint=Muted,modifier=Modifier.size(36.dp));Text(title,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=8.dp));Text(message,color=Muted,fontSize=12.sp,modifier=Modifier.padding(top=4.dp))}}}

fun serviceIcon(key:String)=when(key){"consultation"->Icons.Default.ChatBubbleOutline;"drafting"->Icons.Default.Description;"review"->Icons.Default.Search;"legal-notice"->Icons.Default.MarkEmailRead;"fir-complaint"->Icons.Default.LocalPolice;"property"->Icons.Default.HomeWork;"employment"->Icons.Default.Work;"business"->Icons.Default.BusinessCenter;"cyber"->Icons.Default.Security;else->Icons.Default.HelpOutline}

suspend fun submitRequest(service:String,name:String,phone:String,email:String,message:String):AppRequest?=withContext(Dispatchers.IO){postJson("$SITE/wp-json/lwi-app/v1/request",JSONObject().apply{put("service",service);put("name",name);put("phone",phone);put("message",message);if(email.isNotBlank())put("email",email)}.toString())?.let{o->if(o.optBoolean("success"))AppRequest(o.optInt("request_id"),o.optString("token"),o.optString("status"),o.optString("message"),true)else null}}

suspend fun submitConsultationBooking(name:String,phone:String,email:String,message:String):AppRequest?=withContext(Dispatchers.IO){val d=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date());val t=SimpleDateFormat("HH:mm",Locale.US).format(Date());postJson("$SITE/wp-json/lwi-app/v1/consultation/book",JSONObject().apply{put("name",name);put("phone",phone);if(email.isNotBlank())put("email",email);put("consultation_type","general");put("preferred_date",d);put("preferred_time",t);put("message",message)}.toString())?.let{o->if(o.optBoolean("success"))AppRequest(o.optInt("request_id"),o.optString("token"),o.optString("status"),o.optString("message"),true)else null}}

suspend fun fetchServicePaymentOrder(requestId:Int,token:String,service:String):PaymentOrder?=withContext(Dispatchers.IO){postJson("$SITE/wp-json/lwi-app/v1/service/payment/order",JSONObject().apply{put("request_id",requestId);put("token",token);put("service",service)}.toString())?.let{o->if(o.has("order_id"))PaymentOrder(o.optInt("request_id",requestId),o.getString("order_id"),o.getInt("amount"),o.optString("currency","INR"),o.optString("key_id",RAZORPAY_FALLBACK_KEY),o.optString("service",service))else null}}

suspend fun verifyServicePayment(requestId:Int,token:String,paymentId:String,orderId:String,signature:String):Boolean=withContext(Dispatchers.IO){postJson("$SITE/wp-json/lwi-app/v1/service/payment/verify",JSONObject().apply{put("request_id",requestId);put("token",token);put("payment_id",paymentId);put("order_id",orderId);put("signature",signature)}.toString())?.optBoolean("success",false)==true}

suspend fun fetchArticles():List<Article>=withContext(Dispatchers.IO){try{val o=JSONArray(getText(POSTS));buildList{for(i in 0 until o.length()){val x=o.getJSONObject(i);add(Article(x.getInt("id"),strip(x.getJSONObject("title").getString("rendered")),strip(x.getJSONObject("excerpt").getString("rendered")),x.getJSONObject("content").getString("rendered"),x.getString("date"),x.getString("link")))}}}catch(_:Exception){emptyList()}}

suspend fun fetchStudyAndCourses():Pair<List<Course>,List<StudyItem>>=withContext(Dispatchers.IO){try{val c=JSONArray(getText(COURSES));val courses=buildList{for(i in 0 until c.length()){val x=c.getJSONObject(i);add(Course(x.getInt("id"),strip(x.getJSONObject("title").getString("rendered")),x.getString("link")))}};val s=JSONArray(getText(STUDY_SEARCH));val study=buildList{for(i in 0 until s.length()){val x=s.getJSONObject(i);add(StudyItem(x.getInt("id"),strip(x.getString("title")),x.getString("url")))}};courses to study}catch(_:Exception){emptyList<Course>() to emptyList()}}

suspend fun fetchRequestStatus(id:Int,token:String):RequestStatus?=withContext(Dispatchers.IO){try{val o=JSONObject(getText("$SITE/wp-json/lwi-app/v1/request/$id?token=${Uri.encode(token)}"));if(o.optBoolean("success"))RequestStatus(o.getInt("request_id"),o.getString("service"),o.getString("status"),o.getString("status_label"),o.getString("submitted_at"),o.optString("updated_at"))else null}catch(_:Exception){null}}

fun postJson(url:String,body:String):JSONObject?{return try{val c=URL(url).openConnection() as HttpURLConnection;c.requestMethod="POST";c.doOutput=true;c.connectTimeout=15000;c.readTimeout=20000;c.setRequestProperty("Content-Type","application/json");c.outputStream.use{it.write(body.toByteArray(Charsets.UTF_8))};val stream=if(c.responseCode in 200..299)c.inputStream else c.errorStream;val text=stream?.bufferedReader()?.use{it.readText()}?:"{}";c.disconnect();JSONObject(text)}catch(e:Exception){Log.e(TAG,"POST failed",e);null}}
fun getText(url:String):String{val c=URL(url).openConnection() as HttpURLConnection;c.connectTimeout=15000;c.readTimeout=20000;val t=c.inputStream.bufferedReader().use{it.readText()};c.disconnect();return t}
fun strip(s:String)=s.replace(Regex("<[^>]*>")," ").replace("&nbsp;"," ").replace("&amp;","&").replace(Regex("\\s+")," ").trim()
