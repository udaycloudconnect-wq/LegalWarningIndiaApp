# Legal Warning India — Android App (Next Build)

This build extends the production starter with a live WordPress request workflow.

## Connected live API
- GET `/wp-json/lwi-app/v1/services`
- POST `/wp-json/lwi-app/v1/request`
- GET `/wp-json/lwi-app/v1/request/{id}?token=...`

## App flow
Home → Services → Consultation → Submit Request → Request ID + private token → My Request Status.

## Important
- This is source code, not a signed APK/AAB.
- Razorpay payment integration is intentionally not enabled yet. It should be added server-side after the Razorpay account details/public key and pricing model are finalized.
- Never put a Razorpay secret key inside the Android app.
- Document upload remains a production server-side task with authentication and access controls.
- Legal communication remains informational and avoids guaranteed-outcome claims.
