package com.legalwarningindia.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.razorpay.Checkout
import com.razorpay.PaymentData
import com.razorpay.PaymentResultWithDataListener
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private const val SITE = "https://legalwarningindia.in"
private const val POSTS = "$SITE/wp-json/wp/v2/posts?per_page=20&_fields=id,link,title,excerpt,content,date"
private const val WHATSAPP = "https://wa.me/message/DTAPTLE2NJSOK1"
private const val CONSULTATION = "$SITE/contact-consultation/"
private const val RAZORPAY_KEY_ID = "rzp_test_TaF83g0aFI6IpB"
private const val TAG = "LWI_Razorpay"

data class Article(val id:Int,val title:String,val excerpt:String,val content:String,val date:String)
data class AppRequest(val id:Int,val token:String,val status:String,val message:String,
    val paymentRequired:Boolean=false)
data class PaymentOrder(val orderId:String,val amount:Int,val currency:String,val keyId:String)
data class RequestStatus(val id:Int,val service:String,val status:String,val statusLabel:String,val submittedAt:String,val updatedAt:String)

class MainActivity:ComponentActivity(), PaymentResultWithDataListener{
    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState)
        Checkout.preload(applicationContext)
        setContent{ LegalWarningIndiaApp() }
    }

    override fun onPaymentSuccess(razorpayPaymentID: String, paymentData: PaymentData) {
        val orderId = paymentData.orderId ?: ""
        val signature = paymentData.signature ?: ""
        // Verification is performed server-side. Never verify using the Razorpay secret in the app.
        setContent { PaymentResultScreen("Payment received", "Verifying payment securely…") }
        lifecycleScope.launch {
            val result = verifyPayment(
                requestId = pendingRequestId,
                token = pendingRequestToken,
                paymentId = razorpayPaymentID,
                orderId = orderId,
                signature = signature
            )
            setContent {
                PaymentResultScreen(
                    if (result) "Payment successful" else "Payment verification pending",
                    if (result) "Your payment has been verified and your request is marked paid."
                    else "The payment callback was received, but server verification did not complete. Please check Request Status."
                )
            }
        }
    }

    override fun onPaymentError(code: Int, response: String) {
        Log.e(TAG, "Razorpay payment error: $code $response")
        setContent { PaymentResultScreen("Payment not completed", "No payment was marked paid. You can retry from the consultation flow.") }
    }

    companion object {
        var pendingRequestId: Int = 0
        var pendingRequestToken: String = ""
    }
}

@Composable
fun LegalWarningIndiaApp(){
    val nav=rememberNavController()
    MaterialTheme(colorScheme=lightColorScheme(
        primary=Color(0xFF123B67),secondary=Color(0xFF1E6AA8),
        background=Color(0xFFF7F9FC),surface=Color.White
    )){
        Scaffold(bottomBar={BottomNav(nav)}){pad->
            NavHost(nav,"home",Modifier.padding(pad)){
                composable("home"){Home(nav)}
                composable("news"){News(nav)}
                composable("services"){Services(nav)}
                composable("consult"){Consultation(nav)}
                composable("requests"){MyRequests()}
                composable("courses"){Courses()}
                composable("upload"){DocumentUpload()}
                composable("profile"){Profile()}
                composable("article/{id}"){b->ArticlePage(b.arguments?.getString("id")?.toIntOrNull()?:0)}
            }
        }
    }
}

@Composable
fun BottomNav(nav:NavHostController){
    NavigationBar{
        listOf("home" to "Home","news" to "News","services" to "Services",
            "requests" to "Requests","profile" to "Profile").forEach{(r,l)->
            NavigationBarItem(false,{nav.navigate(r)},icon={
                Icon(when(r){
                    "home"->Icons.Default.Home;"news"->Icons.Default.Article
                    "services"->Icons.Default.Gavel;"requests"->Icons.Default.List
                    else->Icons.Default.Person
                },null)
            },label={Text(l)})
        }
    }
}

@Composable
fun Header(){
    Text("LEGAL WARNING INDIA",style=MaterialTheme.typography.titleLarge,
        fontWeight=FontWeight.Bold,color=Color(0xFF123B67))
    Text("Legal News • Awareness • Practical Procedures")
}

@Composable
fun Home(nav:NavHostController){
    LazyColumn(Modifier.fillMaxSize().background(Color(0xFFF7F9FC)).padding(16.dp),
        verticalArrangement=Arrangement.spacedBy(12.dp)){
        item{
            Header()
            Spacer(Modifier.height(6.dp))
            Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF123B67)),
                shape=RoundedCornerShape(20.dp),modifier=Modifier.fillMaxWidth()){
                Column(Modifier.padding(20.dp)){
                    Text("Know Your Rights",color=Color.White,
                        style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
                    Text("Indian law explained in simple language with practical next steps.",
                        color=Color.White,Modifier.padding(top=8.dp))
                    Button({nav.navigate("news")},Modifier.padding(top=12.dp)){
                        Text("Explore Legal News")
                    }
                }
            }
            Text("What do you need?",style=MaterialTheme.typography.titleMedium,
                fontWeight=FontWeight.Bold,Modifier.padding(top=6.dp))
        }
        items(listOf(
            "Online Consultation" to "consult","Document Drafting" to "services",
            "Document Review" to "services","Cyber Fraud Assistance" to "services",
            "Property Guidance" to "services","Employment Guidance" to "services",
            "Legal Courses" to "courses","Upload Documents" to "upload"
        )){(name,route)->
            Card(Modifier.fillMaxWidth().clickable{nav.navigate(route)},
                shape=RoundedCornerShape(14.dp)){
                Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){
                    Icon(Icons.Default.CheckCircle,null,tint=Color(0xFF1E6AA8))
                    Spacer(Modifier.width(12.dp));Text(name,fontWeight=FontWeight.SemiBold)
                    Spacer(Modifier.weight(1f));Icon(Icons.Default.ChevronRight,null)
                }
            }
        }
    }
}

@Composable
fun News(nav:NavHostController){
    var list by remember{mutableStateOf<List<Article>>(emptyList())}
    var loading by remember{mutableStateOf(true)}
    LaunchedEffect(Unit){list=fetchArticles();loading=false}
    Column(Modifier.fillMaxSize().padding(16.dp)){
        Header();Spacer(Modifier.height(14.dp))
        Text("Latest Legal News",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        if(loading)Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){CircularProgressIndicator()}
        else if(list.isEmpty())Text("Articles could not be loaded. Check your internet connection and try again.")
        else LazyColumn(verticalArrangement=Arrangement.spacedBy(12.dp)){
            items(list){a->
                Card(Modifier.fillMaxWidth().clickable{nav.navigate("article/${a.id}")},
                    shape=RoundedCornerShape(16.dp)){
                    Column(Modifier.padding(16.dp)){
                        Text(a.title,style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold)
                        Text(a.excerpt.take(240),Modifier.padding(top=7.dp))
                        Text("Read Article →",color=Color(0xFF123B67),fontWeight=FontWeight.Bold,
                            Modifier.padding(top=8.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun Services(nav:NavHostController){
    val services=listOf(
        "Online Consultation","Document Drafting","Document Review","Legal Notice",
        "FIR / Complaint Drafting","Property Documentation","Employment Matters",
        "Business Agreements","Cyber Fraud Assistance","General Legal Guidance"
    )
    LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        item{
            Header();Spacer(Modifier.height(14.dp))
            Text("Legal Services",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
            Text("Informational and procedural assistance. No guaranteed outcome is offered.",
                Modifier.padding(top=5.dp,bottom=8.dp))
        }
        items(services){s->
            Card(Modifier.fillMaxWidth().clickable{
                if(s=="Online Consultation") nav.navigate("consult") else nav.navigate("consult")
            },shape=RoundedCornerShape(14.dp)){
                Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){
                    Column(Modifier.weight(1f)){
                        Text(s,fontWeight=FontWeight.SemiBold)
                        Text("Submit a service request",style=MaterialTheme.typography.bodySmall)
                    }
                    Icon(Icons.Default.ChevronRight,null)
                }
            }
        }
    }
}

@Composable
fun Consultation(nav:NavHostController){
    var name by remember{mutableStateOf("")}
    var phone by remember{mutableStateOf("")}
    var email by remember{mutableStateOf("")}
    var message by remember{mutableStateOf("")}
    var submitting by remember{mutableStateOf(false)}
    var result by remember{mutableStateOf<AppRequest?>(null)}
    var error by remember{mutableStateOf("")}
    var paying by remember{mutableStateOf(false)}

    if(result!=null){
        Column(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
            Text("Request Submitted",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
            Text("Your consultation request was received. Payment is required before the request is marked paid.")
            Card(colors=CardDefaults.cardColors(containerColor=Color(0xFFFFF4D6)),
                shape=RoundedCornerShape(14.dp),modifier=Modifier.fillMaxWidth()){
                Column(Modifier.padding(16.dp)){
                    Text("Request ID",fontWeight=FontWeight.Bold)
                    Text("#${result!!.id}",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)
                    Text("Status: ${result!!.status.replace("_"," ").replaceFirstChar{it.uppercase()}}",
                        Modifier.padding(top=6.dp))
                    Text("General Consultation • ₹799",Modifier.padding(top=6.dp))
                }
            }
            Button({
                paying=true
            },enabled=!paying,modifier=Modifier.fillMaxWidth()){
                if(paying) CircularProgressIndicator(modifier=Modifier.size(20.dp),strokeWidth=2.dp)
                else Text("Pay ₹799 with Razorpay")
            }
            LaunchedEffect(paying){
                if(paying){
                    val order=fetchPaymentOrder(result!!.id,result!!.token)
                    if(order==null){
                        error="Payment order could not be created. Please try again."
                        paying=false
                    }else{
                        (LocalContext.current as? MainActivity)?.let { activity ->
                            MainActivity.pendingRequestId=result!!.id
                            MainActivity.pendingRequestToken=result!!.token
                            try{
                                val checkout=Checkout()
                                checkout.setKeyID(order.keyId.ifBlank{RAZORPAY_KEY_ID})
                                val options=JSONObject().apply{
                                    put("name","Legal Warning India")
                                    put("description","General Legal Consultation • Request #${result!!.id}")
                                    put("order_id",order.orderId)
                                    put("amount",order.amount)
                                    put("currency",order.currency)
                                    put("theme.color","#123B67")
                                    put("prefill.name",name)
                                    put("prefill.email",email)
                                    put("prefill.contact",phone)
                                    put("retry",JSONObject().apply{
                                        put("enabled",true)
                                        put("max_count",4)
                                    })
                                }
                                checkout.open(activity,options)
                            }catch(e:Exception){
                                Log.e(TAG,"Unable to open Razorpay Checkout",e)
                                error="Razorpay Checkout could not be opened. Please try again."
                            }
                        }
                        paying=false
                    }
                }
            }
            if(error.isNotBlank()) Text(error,color=MaterialTheme.colorScheme.error)
            OutlinedButton({nav.navigate("requests")},Modifier.fillMaxWidth()){Text("Check Request Status")}
            OutlinedButton({result=null;error=""},Modifier.fillMaxWidth()){Text("Submit Another Request")}
            Text("Keep your Request ID and private token. Never share passwords, OTPs, PINs or Razorpay credentials.",
                style=MaterialTheme.typography.bodySmall)
        }
        return
    }

    LazyColumn(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        item{
            Text("Online Consultation",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
            Text("Request general consultation or procedural information.",
                Modifier.padding(top=6.dp,bottom=8.dp))
            OutlinedTextField(name,{name=it},label={Text("Your Name *")},modifier=Modifier.fillMaxWidth())
            OutlinedTextField(phone,{phone=it},label={Text("Mobile Number *")},modifier=Modifier.fillMaxWidth())
            OutlinedTextField(email,{email=it},label={Text("Email (Optional)")},modifier=Modifier.fillMaxWidth())
            OutlinedTextField(message,{message=it},label={Text("Describe Your Legal Query *")},
                modifier=Modifier.fillMaxWidth(),minLines=4)
            if(error.isNotBlank()) Text(error,color=MaterialTheme.colorScheme.error)
            Button({
                if(name.isBlank()||phone.isBlank()||message.isBlank()){
                    error="Please enter name, mobile number and legal query."
                }else{
                    submitting=true;error=""
                }
            },enabled=!submitting,modifier=Modifier.fillMaxWidth().padding(top=6.dp)){
                if(submitting) CircularProgressIndicator(modifier=Modifier.size(20.dp),strokeWidth=2.dp)
                else Text("Submit Request")
            }
            LaunchedEffect(submitting){
                if(submitting){
                    val r=submitConsultationBooking(name,phone,email,message)
                    if(r!=null){result=r}else{error="Request could not be submitted. Please try again."}
                    submitting=false
                }
            }
            Text("For general legal information only. Do not share passwords, OTPs, PINs or unnecessary sensitive data.",
                style=MaterialTheme.typography.bodySmall,Modifier.padding(top=4.dp))
        }
    }
}

@Composable
fun PaymentResultScreen(title:String,message:String){
    Column(Modifier.fillMaxSize().padding(24.dp),verticalArrangement=Arrangement.spacedBy(14.dp),
        horizontalAlignment=Alignment.CenterHorizontally){
        Spacer(Modifier.height(80.dp))
        Icon(Icons.Default.CheckCircle,null,tint=Color(0xFF1E6AA8),modifier=Modifier.size(64.dp))
        Text(title,style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
        Text(message)
    }
}

@Composable
fun MyRequests(){
    var idText by remember{mutableStateOf("")}
    var token by remember{mutableStateOf("")}
    var loading by remember{mutableStateOf(false)}
    var status by remember{mutableStateOf<RequestStatus?>(null)}
    var error by remember{mutableStateOf("")}

    LazyColumn(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        item{
            Text("My Request Status",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
            Text("Enter the Request ID and private token received after submission.")
            OutlinedTextField(idText,{idText=it.filter{c->c.isDigit()}},label={Text("Request ID")},modifier=Modifier.fillMaxWidth())
            OutlinedTextField(token,{token=it},label={Text("Private Token")},modifier=Modifier.fillMaxWidth())
            if(error.isNotBlank()) Text(error,color=MaterialTheme.colorScheme.error)
            Button({
                error=""
                val id=idText.toIntOrNull()
                if(id==null||token.isBlank()) error="Enter both Request ID and private token."
                else loading=true
            },enabled=!loading,modifier=Modifier.fillMaxWidth()){
                if(loading) CircularProgressIndicator(modifier=Modifier.size(20.dp),strokeWidth=2.dp)
                else Text("Check Status")
            }
            LaunchedEffect(loading){
                if(loading){
                    status=fetchRequestStatus(idText.toInt(),token)
                    if(status==null) error="Request not found or token is invalid."
                    loading=false
                }
            }
            status?.let{s->
                Card(shape=RoundedCornerShape(16.dp),modifier=Modifier.fillMaxWidth().padding(top=8.dp)){
                    Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){
                        Text("Request #${s.id}",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)
                        Text("Service: ${s.service}")
                        Text("Status: ${s.statusLabel}",fontWeight=FontWeight.Bold)
                        Text("Submitted: ${s.submittedAt}")
                        if(s.updatedAt.isNotBlank()) Text("Updated: ${s.updatedAt}")
                    }
                }
            }
        }
    }
}

@Composable
fun Courses(){
    val courses=listOf(
        "BNS • BNSS • BSA Practical Legal Awareness",
        "Cyber Crime & Digital Evidence",
        "FIR to Trial: Practical Criminal Procedure",
        "Legal Drafting & Complaint Writing",
        "Practical Property & Revenue Procedures"
    )
    LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        item{
            Text("Legal Courses",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
            Text("Structured learning for practical legal awareness.",
                Modifier.padding(top=5.dp))
        }
        items(courses){c->
            Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp)){
                Column(Modifier.padding(16.dp)){
                    Text(c,style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold)
                    Text("Course details and secure enrollment can be connected to the website LMS.",
                        Modifier.padding(top=6.dp))
                    OutlinedButton({},Modifier.padding(top=8.dp)){Text("View Course")}
                }
            }
        }
    }
}

@Composable
fun DocumentUpload(){
    Column(Modifier.fillMaxSize().padding(18.dp)){
        Text("Secure Document Upload",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
        Text("Production implementation should upload files to a secured server endpoint.",
            Modifier.padding(top=8.dp))
        Spacer(Modifier.height(18.dp))
        Card(shape=RoundedCornerShape(16.dp),modifier=Modifier.fillMaxWidth()){
            Column(Modifier.padding(18.dp)){
                Icon(Icons.Default.UploadFile,null)
                Text("PDF / JPG / PNG",fontWeight=FontWeight.Bold,Modifier.padding(top=8.dp))
                Text("Maximum size and file-type validation will be enforced server-side.",
                    Modifier.padding(top=4.dp))
                Button({},Modifier.padding(top=12.dp)){Text("Choose Document")}
            }
        }
        Spacer(Modifier.height(16.dp))
        Text("Privacy note",fontWeight=FontWeight.Bold)
        Text("Never send passwords, OTPs, card PINs or unnecessary personal information. A production build must use authenticated HTTPS uploads, access controls and secure storage.")
    }
}

@Composable
fun Profile(){
    Column(Modifier.fillMaxSize().padding(20.dp)){
        Text("About",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        Text("Uday Singh, Advocate",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)
        Text("LL.B., M.Sc., BCA",Modifier.padding(top=6.dp))
        Text("Focus: Cyber Matters, Criminal Matters, Digital Evidence & Practical Legal Procedures.",
            Modifier.padding(top=5.dp))
        Spacer(Modifier.height(20.dp))
        Text("Legal Warning India",fontWeight=FontWeight.Bold)
        Text("Legal awareness, current legal developments and practical procedural information.",
            Modifier.padding(top=5.dp))
        Spacer(Modifier.height(20.dp))
        Text("Disclaimer",fontWeight=FontWeight.Bold)
        Text("This app is for general legal information and awareness purposes only. It does not constitute legal advice or solicitation. Communication is purely informational, in compliance with Bar Council of India Rule 36.",
            Modifier.padding(top=5.dp))
    }
}

@Composable
fun ArticlePage(id:Int){
    var article by remember{mutableStateOf<Article?>(null)}
    LaunchedEffect(id){article=fetchArticles().firstOrNull{it.id==id}}
    if(article==null)Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){CircularProgressIndicator()}
    else LazyColumn(Modifier.fillMaxSize().padding(18.dp)){
        item{
            Text(article!!.title,style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
            Text("Published by The Legal Warning India and written by Advocate Uday Singh.",
                style=MaterialTheme.typography.bodySmall,Modifier.padding(top=8.dp))
            Text(strip(article!!.content),style=MaterialTheme.typography.bodyLarge,
                Modifier.padding(top=18.dp))
        }
    }
}

suspend fun submitConsultationBooking(
    name:String, phone:String, email:String, message:String
):AppRequest? = withContext(Dispatchers.IO){
    try{
        val c=URL("$SITE/wp-json/lwi-app/v1/consultation/book").openConnection() as HttpURLConnection
        c.requestMethod="POST";c.doOutput=true;c.connectTimeout=10000;c.readTimeout=15000
        c.setRequestProperty("Content-Type","application/json")
        val body=JSONObject().apply{
            put("name",name);put("phone",phone)
            if(email.isNotBlank()) put("email",email)
            put("consultation_type","general")
            put("preferred_date","2026-09-10")
            put("preferred_time","18:00")
            put("message",message)
        }.toString()
        c.outputStream.use{it.write(body.toByteArray())}
        val response=(if(c.responseCode in 200..299)c.inputStream else c.errorStream)
            .bufferedReader().use{it.readText()}
        c.disconnect()
        val o=JSONObject(response)
        if(!o.optBoolean("success",false)) null
        else AppRequest(
            o.getInt("request_id"),o.getString("token"),
            o.optString("status","payment_pending"),
            o.optString("message","Consultation booking created."),
            o.optBoolean("payment_required",true)
        )
    }catch(_:Exception){null}
}

suspend fun fetchPaymentOrder(requestId:Int,token:String):PaymentOrder? = withContext(Dispatchers.IO){
    try{
        val c=URL("$SITE/wp-json/lwi-app/v1/payment/order").openConnection() as HttpURLConnection
        c.requestMethod="POST";c.doOutput=true;c.connectTimeout=10000;c.readTimeout=15000
        c.setRequestProperty("Content-Type","application/json")
        val body=JSONObject().apply{
            put("request_id",requestId);put("token",token)
        }.toString()
        c.outputStream.use{it.write(body.toByteArray())}
        val response=(if(c.responseCode in 200..299)c.inputStream else c.errorStream)
            .bufferedReader().use{it.readText()}
        c.disconnect()
        val o=JSONObject(response)
        if(!o.optBoolean("success",false)) null
        else PaymentOrder(
            o.getString("order_id"),
            o.getInt("amount"),
            o.optString("currency","INR"),
            o.optString("key_id",RAZORPAY_KEY_ID)
        )
    }catch(e:Exception){
        Log.e(TAG,"Order creation failed",e);null
    }
}

suspend fun verifyPayment(
    requestId:Int, token:String, paymentId:String, orderId:String, signature:String
):Boolean = withContext(Dispatchers.IO){
    try{
        val c=URL("$SITE/wp-json/lwi-app/v1/payment/verify").openConnection() as HttpURLConnection
        c.requestMethod="POST";c.doOutput=true;c.connectTimeout=10000;c.readTimeout=15000
        c.setRequestProperty("Content-Type","application/json")
        val body=JSONObject().apply{
            put("request_id",requestId);put("token",token)
            put("razorpay_payment_id",paymentId)
            put("razorpay_order_id",orderId)
            put("razorpay_signature",signature)
        }.toString()
        c.outputStream.use{it.write(body.toByteArray())}
        val response=(if(c.responseCode in 200..299)c.inputStream else c.errorStream)
            .bufferedReader().use{it.readText()}
        c.disconnect()
        val o=JSONObject(response)
        o.optBoolean("success",false) && o.optString("status")=="paid"
    }catch(e:Exception){
        Log.e(TAG,"Payment verification failed",e);false
    }
}

suspend fun fetchArticles():List<Article>=withContext(Dispatchers.IO){
    try{
        val c=URL(POSTS).openConnection() as HttpURLConnection
        c.connectTimeout=10000;c.readTimeout=10000
        val text=c.inputStream.bufferedReader().use{it.readText()};c.disconnect()
        val a=JSONArray(text)
        buildList{
            for(i in 0 until a.length()){
                val o=a.getJSONObject(i)
                add(Article(
                    o.getInt("id"),
                    strip(o.getJSONObject("title").getString("rendered")),
                    strip(o.getJSONObject("excerpt").getString("rendered")),
                    o.getJSONObject("content").getString("rendered"),
                    o.getString("date")
                ))
            }
        }
    }catch(_:Exception){emptyList()}
}

suspend fun submitRequest(service:String,name:String,phone:String,email:String,message:String):AppRequest? =
    withContext(Dispatchers.IO){
        try{
            val c=URL("$SITE/wp-json/lwi-app/v1/request").openConnection() as HttpURLConnection
            c.requestMethod="POST";c.doOutput=true;c.connectTimeout=10000;c.readTimeout=10000
            c.setRequestProperty("Content-Type","application/json")
            val body=JSONObject().apply{
                put("service",service);put("name",name);put("phone",phone);put("message",message)
                if(email.isNotBlank()) put("email",email)
            }.toString()
            c.outputStream.use{it.write(body.toByteArray())}
            val response=c.inputStream.bufferedReader().use{it.readText()}
            c.disconnect()
            val o=JSONObject(response)
            if(!o.optBoolean("success",false)) null
            else AppRequest(o.getInt("request_id"),o.getString("token"),o.getString("status"),o.getString("message"))
        }catch(_:Exception){null}
    }

suspend fun fetchRequestStatus(id:Int,token:String):RequestStatus? = withContext(Dispatchers.IO){
    try{
        val c=URL("$SITE/wp-json/lwi-app/v1/request/$id?token=${Uri.encode(token)}").openConnection() as HttpURLConnection
        c.connectTimeout=10000;c.readTimeout=10000
        val response=c.inputStream.bufferedReader().use{it.readText()}
        c.disconnect()
        val o=JSONObject(response)
        if(!o.optBoolean("success",false)) null
        else RequestStatus(
            o.getInt("request_id"),o.getString("service"),o.getString("status"),
            o.getString("status_label"),o.getString("submitted_at"),o.optString("updated_at")
        )
    }catch(_:Exception){null}
}

fun strip(s:String)=s.replace(Regex("<[^>]*>")," ")
    .replace("&nbsp;"," ").replace("&amp;","&")
    .replace(Regex("\s+")," ").trim()
