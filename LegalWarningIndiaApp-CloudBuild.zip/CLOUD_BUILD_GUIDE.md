# Legal Warning India — Cloud APK Build

The repository includes `.github/workflows/android.yml`.

When the project is placed in a GitHub repository, the workflow can build the debug APK in GitHub Actions without Android Studio on the user's phone/laptop.

Important:
- This is a debug APK for testing.
- Do not put Razorpay Secret Key in the repository.
- The configured Razorpay Test Key ID is public/test-only.
- A Play Store release requires a properly managed signing key and an AAB release build.
